package in.Cand.pojo;

public class Interviewer extends Candidate {
	private int InterviewerID;
	private String InterviewerName;
	private int InterviewerPhone;
	private String InterviewerEmail;
	private int InterviewerGCMLevel;
	private String InterviewerManagerName;

	private Feedback evaFeedback;

	// private Feedback evaFeedback;

	public int getInterviewerID() {
		return InterviewerID;
	}

	public void setInterviewerID(int interviewerID) {
		InterviewerID = interviewerID;
	}

	public String getInterviewerName() {
		return InterviewerName;
	}

	public void setInterviewerName(String interviewerName) {
		InterviewerName = interviewerName;
	}

	public int getInterviewerPhone() {
		return InterviewerPhone;
	}

	public void setInterviewerPhone(int interviewerPhone) {
		InterviewerPhone = interviewerPhone;
	}

	public String getInterviewerEmail() {
		return InterviewerEmail;
	}

	public void setInterviewerEmail(String interviewerEmail) {
		InterviewerEmail = interviewerEmail;
	}

	public int getInterviewerGCMLevel() {
		return InterviewerGCMLevel;
	}

	public void setInterviewerGCMLevel(int interviewerGCMLevel) {
		InterviewerGCMLevel = interviewerGCMLevel;
	}

	public String getInterviewerManagerName() {
		return InterviewerManagerName;
	}

	public void setInterviewerManagerName(String interviewerManagerName) {
		InterviewerManagerName = interviewerManagerName;
	}

	public void setEvaFeedback(Feedback evaFeedback) {
		this.evaFeedback = evaFeedback;
	}

	@Override
	public String toString() {
		return "Interviewer [InterviewerID=" + InterviewerID + ", InterviewerName=" + InterviewerName
				+ ", InterviewerPhone=" + InterviewerPhone + ", InterviewerEmail=" + InterviewerEmail
				+ ", InterviewerGCMLevel=" + InterviewerGCMLevel + ", InterviewerManagerName=" + InterviewerManagerName
				+ ", evaFeedback=" + evaFeedback + ", CandidateID=" + CandidateID + ", CandidateName=" + CandidateName
				+ ", CandidatePhone=" + CandidatePhone + ", CandidateEmail=" + CandidateEmail + ", CandidateResume="
				+ CandidateResume + ", CandidateComment=" + CandidateComment + "]";
	}

}
