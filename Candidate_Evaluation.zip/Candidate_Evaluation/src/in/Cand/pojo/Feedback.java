package in.Cand.pojo;

public class Feedback{
	private int FeedbackID;
	private int FeedbackEvalutorID;
	private String CandidateID;
	
	private int Feedback1ScreeingLevel;
	private String FeedbackStatus;
	private String FeedbackComment;
	public int getFeedbackID() {
		return FeedbackID;
	}
	public void setFeedbackID(int feedbackID) {
		FeedbackID = feedbackID;
	}
	public int getFeedbackEvalutorID() {
		return FeedbackEvalutorID;
	}
	public void setFeedbackEvalutorID(int feedbackEvalutorID) {
		FeedbackEvalutorID = feedbackEvalutorID;
	}
	public String getCandidateID() {
		return CandidateID;
	}
	public void setCandidateID(String candidateID) {
		CandidateID = candidateID;
	}
	public int getFeedback1ScreeingLevel() {
		return Feedback1ScreeingLevel;
	}
	public void setFeedback1ScreeingLevel(int feedback1ScreeingLevel) {
		Feedback1ScreeingLevel = feedback1ScreeingLevel;
	}
	public String getFeedbackStatus() {
		return FeedbackStatus;
	}
	public void setFeedbackStatus(String feedbackStatus) {
		FeedbackStatus = feedbackStatus;
	}
	public String getFeedbackComment() {
		return FeedbackComment;
	}
	public void setFeedbackComment(String feedbackComment) {
		FeedbackComment = feedbackComment;
	}
	@Override
	public String toString() {
		return "Feedback [FeedbackID=" + FeedbackID + ", FeedbackEvalutorID=" + FeedbackEvalutorID + ", CandidateID="
				+ CandidateID + ", Feedback1ScreeingLevel=" + Feedback1ScreeingLevel + ", FeedbackStatus="
				+ FeedbackStatus + ", FeedbackComment=" + FeedbackComment + "]";
	}
	

	
	

}
