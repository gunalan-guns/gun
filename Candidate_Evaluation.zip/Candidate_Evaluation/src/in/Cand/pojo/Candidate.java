package in.Cand.pojo;

public class Candidate {
	protected int CandidateID;
	 protected String CandidateName;
	 protected int CandidatePhone;
	 protected String CandidateEmail;
	 protected String CandidateResume;
	 protected String CandidateComment;
	
	

	
	@Override
	public String toString() {
		return "Candidate [CandidateID=" + CandidateID + ", CandidateName=" + CandidateName + ", CandidatePhone="
				+ CandidatePhone + ", CandidateEmail=" + CandidateEmail + ", CandidateResume=" + CandidateResume
				+ ", CandidateComment=" + CandidateComment + "]";
	}


	public int getCandidateID() {
		return CandidateID;
	}


	public void setCandidateID(int candidateID) {
		CandidateID = candidateID;
	}


	public String getCandidateName() {
		return CandidateName;
	}


	public void setCandidateName(String candidateName) {
		CandidateName = candidateName;
	}


	public int getCandidatePhone() {
		return CandidatePhone;
	}

	public void setCandidatePhone(int candidatePhone) {
		CandidatePhone = candidatePhone;
	}


	public String getCandidateEmail() {
		return CandidateEmail;
	}

	public void setCandidateEmail(String candidateEmail) {
		CandidateEmail = candidateEmail;
	}

	public String getCandidateResume() {
		return CandidateResume;
	}

	public void setCandidateResume(String candidateResume) {
		CandidateResume = candidateResume;
	}

	public String getCandidateComment() {
		return CandidateComment;
	}

	public void setCandidateComment(String candidateComment) {
		CandidateComment = candidateComment;
	}

}
