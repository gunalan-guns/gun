package in.Cand.pojo;

public class TestClass {

	public static void main(String[] args) {
		Interviewer eva =new Interviewer();
		
		
		eva.setCandidateID(1);
		eva.setCandidateName("guns");
		eva.setCandidatePhone(423661);
		eva.setCandidateEmail("guns@atos.net");
		eva.setCandidateResume("guns.pdf");
		eva.setCandidateComment("good");
		eva.setInterviewerID(2);
		eva.setInterviewerName("Guruprasad");
		eva.setInterviewerPhone(45623);
		eva.setInterviewerEmail("guruprasad@atos.net");
		eva.setInterviewerGCMLevel(2);
		

		
	//	System.out.println(eva);
		
		Feedback feedback = new Feedback();
		feedback.setFeedbackID(1);
		feedback.setFeedbackEvalutorID(2);
		feedback.setFeedback1ScreeingLevel(5);
		feedback.setFeedbackStatus("Selected");
		feedback.setFeedbackComment("good");
		
		eva.setEvaFeedback(feedback);
		System.out.println(eva);
		
		/*
		 * Evalution evalution = new Evalution(); 
		 * evalution.setEvalName("Guru");
		 * evalution.setReport("Good");
		 * 
		 * feed.setFeedEvalution(evalution);
		 *  System.out.println(feed);
		 */
		/*
		 * Evalution Evalution = new Evalution(); Evalution.setEvalName("Guru");
		 * Evalution.setEvalName("Good");
		 * 
		 * Evalution.setEvalutionFeedback(feed);
		 * 
		 * System.out.println(Evalution);
		 */
		//Evalution evalution = new Evalution();
		
	//	eva.setEvalName("guru");
		//eva.setReport("negative");
		
	//	System.out.println(eva);
		
	}

}
