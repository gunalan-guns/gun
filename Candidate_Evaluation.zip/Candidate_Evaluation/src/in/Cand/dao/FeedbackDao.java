package in.Cand.dao;

import java.util.List;


import in.Cand.pojo.Feedback;

public interface FeedbackDao {
	
	void add(Feedback feedback);
	List<Feedback> findAll();

}
