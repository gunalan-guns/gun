package in.Cand.dao;

import java.util.List;

import in.Cand.pojo.Interviewer;

public interface InterviewerDao {
	
	void add(Interviewer interviewer);
	List<Interviewer> findAll();

}
