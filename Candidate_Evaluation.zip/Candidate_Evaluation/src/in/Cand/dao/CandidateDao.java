package in.Cand.dao;

import java.util.List;

import in.Cand.pojo.Candidate;

public interface CandidateDao {
	void add(Candidate candidate);
	List<Candidate> findAll();
}
