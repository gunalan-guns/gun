package in.Cand.dao.impl;

import java.util.List;

import javax.swing.tree.RowMapper;

import in.Cand.dao.InterviewerDao;
import in.Cand.pojo.Feedback;
import in.Cand.pojo.Interviewer;


public class InterviewerDaoImpl implements InterviewerDao {
	
	JdbcTemplate jdbcTemplate;
	String sqlQuery;
	
	@Override
	public void add(Interviewer interviewer) {
		sqlQuery="insert into Interviwer(InterviewerID, InterviewerName, InterviewerPhone,  InterviewerEmail,InterviewerGCMLevel,InterviewerManagerName)\r\n"
				+ "values(?,?,?,?,?)";
		// TODO Auto-generated method stub
		
		jdbcTemplate.update(sqlQuery,interviewer.getInterviewerID(),interviewer.getInterviewerName(),interviewer.getInterviewerPhone(),interviewer.getInterviewerEmail(),interviewer.getInterviewerGCMLevel(),interviewer.getInterviewerManagerName());
		
	}

	@Override
	public List<Interviewer> findAll() {
		sqlQuery="Select * from interviewer";
		
		RowMapper<Interviewer> rowMapper=(rs,rowcnt)->{
			Interviewer eva=new Interviewer();
			eva.setInterviewerID(rs.getInt(1));
			eva.setInterviewerName(rs.getString(2));
			eva.setInterviewerPhone(rs.getInt(3));
			eva.setInterviewerEmail(rs.getString(4));
			eva.setInterviewerGCMLevel(rs.getString(5));
			eva.setInterviewerManagerName(rs.getString(6));
			
		};
		
		
		// TODO Auto-generated method stub
		List<Interviewer> ilist=jdbcTemplate.query(sqlQuery,rowMapper);
		return ilist;
	}
	
	

}
