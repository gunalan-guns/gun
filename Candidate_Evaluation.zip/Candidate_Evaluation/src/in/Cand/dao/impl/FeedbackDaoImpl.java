package in.Cand.dao.impl;

import java.util.List;

import javax.swing.tree.RowMapper;

import in.Cand.dao.FeedbackDao;
import in.Cand.pojo.Feedback;


public class FeedbackDaoImpl implements FeedbackDao{
	
	JdbcTemplate jdbcTemplate;
	String sqlQuery;
	
	@Override
	public void add(Feedback feedback) {
		sqlQuery="insert into Feedback(FeedbackID, FeedbackEvalutorID, CandidateID,  Feedback1ScreeingLevel,FeedbackStatus,FeedbackComment)\r\n"
				+ "values(?,?,?,?,?)";
		// TODO Auto-generated method stub
		
		jdbcTemplate.update(sqlQuery,feedback.getFeedbackID(),feedback.getFeedbackEvalutorID(),feedback.getCandidateID(),feedback.getFeedback1ScreeingLevel(),feedback.getFeedbackStatus(),feedback.getFeedbackComment());
		
	}

	@Override
	public List<Feedback> findAll() {
		sqlQuery="Select * from feedback";
		
		RowMapper<Feedback> rowMapper=(rs,rowcnt)->{
			Feedback feed=new Feedback();
			feed.setFeedbackID(rs.getInt(1));
			feed.setFeedbackEvalutorID(rs.getInt(2));
			feed.setCandidateID(rs.getInt(3));
			feed.setFeedback1ScreeingLevel(rs.getString(4));
			feed.setFeedbackStatus(rs.getString(5));
			feed.setFeedbackComment(rs.getString(6));
			
		};
		
		
		// TODO Auto-generated method stub
		List<Feedback> flist=jdbcTemplate.query(sqlQuery,rowMapper);
		return flist;
	}

}
