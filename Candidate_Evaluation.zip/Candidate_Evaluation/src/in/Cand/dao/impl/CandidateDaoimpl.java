package in.Cand.dao.impl;

import java.util.List;

import javax.swing.tree.RowMapper;

import org.springframework.jdbc.core.JdbcTemplate;

import in.Cand.dao.CandidateDao;
import in.Cand.pojo.Candidate;
import in.Cand.pojo.Interviewer;

public class CandidateDaoimpl implements CandidateDao
{
	JdbcTemplate jdbcTemplate;
	String sqlQuery;
	
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void add(Candidate candidate) {
		sqlQuery="insert into Candidate(CandidateID, CandidateName, CandidatePhone, CandidateEmail,CandidateResume,CandidateComment)\r\n"
				+ "values(?,?,?,?,?)";
		// TODO Auto-generated method stub
		
		jdbcTemplate.update(sqlQuery,candidate.getCandidateID(),candidate.getCandidateName(),candidate.getCandidateEmail(),candidate.getCandidatePhone(),candidate.getCandidateResume(),candidate.getCandidateComment());
		
	}

	@Override
	public List<Candidate> findAll() {
		sqlQuery="Select * from candidate";
		// TODO Auto-generated method stub
		RowMapper<Candidate> rowMapper=(rs,rowcnt)->{
			Candidate can=new Candidate();
			can.setCandidateID(rs.getInt(1));
			can.setCandidateName(rs.getString(2));
			can.setCandidatePhone(rs.getInt(3));
			can.setCandidateEmail(rs.getString(4));
			can.setCandidateResume(rs.getString(5));
			can.setCandidateComment(rs.getString(6));
			
		};
		
		
		// TODO Auto-generated method stub
		List<Candidate> elist=jdbcTemplate.query(sqlQuery,rowMapper);
		return elist;
	}

}
