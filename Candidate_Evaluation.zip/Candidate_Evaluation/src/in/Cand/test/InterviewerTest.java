package in.Cand.test;

import java.util.List;

import in.Cand.dao.CandidateDao;
import in.Cand.dao.InterviewerDao;
import in.Cand.dao.impl.CandidateDaoimpl;
import in.Cand.dao.impl.InterviewerDaoImpl;
import in.Cand.pojo.Candidate;
import in.Cand.pojo.Interviewer;

public class InterviewerTest {
	
	public static void main(String[] args) {
		ApplicationContext context =new ClassPathXmlApplicationContext("bean2.xml");
		InterviewerDao interviewerDao=(InterviewerDaoImpl)context.getBean("interviewerDao");
		List<Interviewer> ilist=interviewerDao.findAll();
		System.out.println(ilist);
	}

}
