package in.Cand.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import in.Cand.dao.FeedbackDao;

import in.Cand.dao.impl.FeedbackDaoImpl;

import in.Cand.pojo.Feedback;

public class FeedbackTest {
	
	public static void main(String[] args) {
		ApplicationContext context =new ClassPathXmlApplicationContext("bean2.xml");
		FeedbackDao feedbackDao=(FeedbackDaoImpl)context.getBean("feedbackDao");
		List<Feedback> flist=feedbackDao.findAll();
		System.out.println(flist);
	}

}
