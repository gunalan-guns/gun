package in.Cand.test;

import java.util.List;

import in.Cand.dao.CandidateDao;
import in.Cand.dao.impl.CandidateDaoimpl;
import in.Cand.pojo.Candidate;

public class CandidateTest {

	
	public static void main(String[] args) {
		ApplicationContext context =new ClassPathXmlApplicationContext("bean2.xml");
		CandidateDao candidateDao=(CandidateDaoimpl)context.getBean("candidateDao");
		List<Candidate> elist=candidateDao.findAll();
		System.out.println(elist);
	}
}
