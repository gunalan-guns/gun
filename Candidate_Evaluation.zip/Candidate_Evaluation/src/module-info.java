module Candidate_Evaluation {
	requires java.desktop;
	requires spring.context;
}